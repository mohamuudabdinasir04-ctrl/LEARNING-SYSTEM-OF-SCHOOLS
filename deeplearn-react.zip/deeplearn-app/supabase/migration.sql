-- ============================================================
-- DeepLearn — Supabase migration (React version)
-- Run once in: Supabase Dashboard → SQL Editor → New query
-- Project: ttehmlqmjfjwnzibcexz
-- ============================================================

create extension if not exists pgcrypto;

-- ============================================================
-- 1. SECURE LOGIN
--    Passwords are hashed with bcrypt. RLS blocks any direct read
--    of `profiles`. Login goes through login_user(), which runs
--    server-side and returns only non-secret fields.
-- ============================================================

-- 1a. Hash any existing plaintext passwords (safe to run once;
--     rows already hashed with bcrypt are skipped).
update public.profiles
set password = crypt(password, gen_salt('bf'))
where password is not null
  and password !~ '^\$2[aby]\$';

alter table public.profiles enable row level security;
-- No select/insert/update policy is created for `anon` here on purpose:
-- direct access to `profiles` (which still has the password column) is
-- blocked. Everything else reads through profiles_directory (below) or
-- the login_user RPC.

create or replace function public.login_user(p_id text, p_password text)
returns table (id text, name text, role text, class_id text, status text)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.profiles
    where profiles.id = p_id
      and profiles.password = crypt(p_password, profiles.password)
  ) then
    raise exception 'invalid_credentials';
  end if;

  if exists (
    select 1 from public.profiles
    where profiles.id = p_id and profiles.status <> 'ACTIVE'
  ) then
    raise exception 'account_disabled';
  end if;

  return query
    select profiles.id, profiles.name, profiles.role, profiles.class_id, profiles.status
    from public.profiles
    where profiles.id = p_id;
end;
$$;

grant execute on function public.login_user(text, text) to anon;

-- ============================================================
-- 2. PASSWORD-FREE DIRECTORY VIEW
--    Lets Super Admin / School Admin dashboards list teachers and
--    students (name, role, class, status) without ever exposing
--    the password column.
--
-- ⚠️ SECURITY NOTE: this app has no real per-user session (login
-- is a custom RPC, not Supabase Auth), so this view is world-
-- readable to anyone holding the anon key — matching the trust
-- model of the rest of the app. If you later migrate logins to
-- Supabase Auth, replace this with RLS policies keyed off
-- auth.uid() / auth.jwt() so only admins can read it.
-- ============================================================
create or replace view public.profiles_directory as
select id, name, role, class_id, status
from public.profiles;

grant select on public.profiles_directory to anon;

-- ============================================================
-- 3. SHARED SYSTEM STATUS (global on/off switch)
-- ============================================================
create table if not exists public.system_status (
  id int primary key default 1,
  active boolean not null default true,
  updated_at timestamptz not null default now(),
  constraint single_row check (id = 1)
);

insert into public.system_status (id, active)
values (1, true)
on conflict (id) do nothing;

alter table public.system_status enable row level security;

drop policy if exists "system_status_select" on public.system_status;
create policy "system_status_select" on public.system_status
  for select using (true);

drop policy if exists "system_status_update" on public.system_status;
create policy "system_status_update" on public.system_status
  for update using (true);
-- Same caveat as above: without real auth this cannot be restricted
-- to super_admin only at the database level yet.

-- ============================================================
-- 4. SHARED LESSONS
-- ============================================================
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  target_class text not null,
  title text not null,
  content text not null,
  image_url text,
  video_url text,
  teacher_id text,
  created_at timestamptz not null default now()
);

alter table public.lessons enable row level security;

drop policy if exists "lessons_select" on public.lessons;
create policy "lessons_select" on public.lessons
  for select using (true);

drop policy if exists "lessons_insert" on public.lessons;
create policy "lessons_insert" on public.lessons
  for insert with check (true);

-- ============================================================
-- 5. REALTIME
--    Lets the React app subscribe to live changes so a new lesson
--    or a system status toggle appears instantly for everyone,
--    without a page refresh.
-- ============================================================
alter publication supabase_realtime add table public.lessons;
alter publication supabase_realtime add table public.system_status;
