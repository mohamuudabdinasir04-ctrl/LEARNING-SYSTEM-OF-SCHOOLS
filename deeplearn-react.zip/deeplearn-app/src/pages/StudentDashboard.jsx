import React, { useEffect, useState } from 'react'
import { BookOpen } from 'lucide-react'
import DashboardLayout from '../components/DashboardLayout'
import LessonCard from '../components/LessonCard'
import ChatTutor from '../components/ChatTutor'
import { useAuth } from '../context/AuthContext'
import { fetchLessonsForClass, subscribeToLessons } from '../lib/api'

export default function StudentDashboard() {
  const { currentUser } = useAuth()
  const studentClass = currentUser.class_id || 'F2'
  const [lessons, setLessons] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        const data = await fetchLessonsForClass(studentClass)
        if (mounted) setLessons(data)
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()

    // New lessons posted by a teacher appear instantly, no refresh needed.
    const unsubscribe = subscribeToLessons((newLesson) => {
      if (newLesson.target_class === studentClass) {
        setLessons((prev) => [newLesson, ...prev])
      }
    })

    return () => {
      mounted = false
      unsubscribe()
    }
  }, [studentClass])

  return (
    <DashboardLayout
      title="Student Learning Portal"
      subtitle="Access assigned curriculum lessons and restricted 100% curriculum AI Tutor"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h4 className="font-bold text-sm text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-indigo-400" /> Casharrada Fasalkaaga ({studentClass})
          </h4>
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {loading ? (
              <p className="text-xs text-slate-400">Soo dejinaya...</p>
            ) : lessons.length === 0 ? (
              <p className="text-xs text-slate-400">Weli lama soo gelin casharro cusub fasalkan.</p>
            ) : (
              lessons.map((l) => <LessonCard key={l.id} lesson={l} />)
            )}
          </div>
        </div>

        <ChatTutor lessons={lessons} studentClass={studentClass} />
      </div>
    </DashboardLayout>
  )
}
