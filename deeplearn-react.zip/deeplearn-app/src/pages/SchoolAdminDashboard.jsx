import React, { useEffect, useMemo, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import StatCard from '../components/StatCard'
import { fetchDirectory, fetchAllLessons } from '../lib/api'

export default function SchoolAdminDashboard() {
  const [directory, setDirectory] = useState([])
  const [lessons, setLessons] = useState([])
  const [loading, setLoading] = useState(true)
  const [classFilter, setClassFilter] = useState('ALL')

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        const [dir, lsn] = await Promise.all([fetchDirectory(), fetchAllLessons()])
        if (mounted) {
          setDirectory(dir)
          setLessons(lsn)
        }
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
    return () => {
      mounted = false
    }
  }, [])

  const teachers = useMemo(() => directory.filter((p) => p.role === 'teacher'), [directory])
  const students = useMemo(() => directory.filter((p) => p.role === 'student'), [directory])

  const classIds = useMemo(() => {
    const set = new Set(students.map((s) => s.class_id).filter(Boolean))
    return ['ALL', ...Array.from(set).sort()]
  }, [students])

  const visibleStudents = useMemo(
    () => (classFilter === 'ALL' ? students : students.filter((s) => s.class_id === classFilter)),
    [students, classFilter]
  )

  const lessonsPerClass = useMemo(() => {
    const map = {}
    lessons.forEach((l) => {
      map[l.target_class] = (map[l.target_class] || 0) + 1
    })
    return map
  }, [lessons])

  return (
    <DashboardLayout
      title="School Administration Panel"
      subtitle="Monitoring teachers, students, and active classes (C1-F4)"
    >
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label="Assigned Teachers"
          value={loading ? '…' : teachers.length}
          hint="Live from Supabase"
          hintColor="text-emerald-400"
        />
        <StatCard
          label="Enrolled Students"
          value={loading ? '…' : students.length}
          hint="Primary & Secondary Classes"
          hintColor="text-sky-400"
        />
        <StatCard
          label="Classes with Lessons"
          value={loading ? '…' : Object.keys(lessonsPerClass).length}
          hint="Full Curriculum Live"
          hintColor="text-purple-400"
        />
      </div>

      <div className="bg-cardBg p-6 rounded-3xl border border-slate-800/80 shadow-lg">
        <h4 className="font-bold text-base text-white mb-4">Teachers</h4>
        {loading ? (
          <p className="text-xs text-slate-400">Soo dejinaya...</p>
        ) : teachers.length === 0 ? (
          <p className="text-xs text-slate-400">Weli lama diiwaan gelin macallimiin.</p>
        ) : (
          <div className="space-y-3">
            {teachers.map((t) => (
              <div
                key={t.id}
                className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 flex justify-between items-center"
              >
                <div>
                  <h5 className="text-sm font-bold text-white">{t.name}</h5>
                  <p className="text-xs text-slate-400">ID: {t.id}</p>
                </div>
                <span
                  className={`px-3 py-1 text-xs rounded-xl border font-semibold ${
                    t.status === 'ACTIVE'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-red-500/10 text-red-400 border-red-500/20'
                  }`}
                >
                  {t.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-cardBg p-6 rounded-3xl border border-slate-800/80 shadow-lg">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h4 className="font-bold text-base text-white">Students by Class</h4>
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
          >
            {classIds.map((c) => (
              <option key={c} value={c}>
                {c === 'ALL' ? 'Dhammaan Fasallada' : c}
              </option>
            ))}
          </select>
        </div>
        {loading ? (
          <p className="text-xs text-slate-400">Soo dejinaya...</p>
        ) : visibleStudents.length === 0 ? (
          <p className="text-xs text-slate-400">Ma jiraan arday ku qoran fasalkan.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {visibleStudents.map((s) => (
              <div
                key={s.id}
                className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 flex justify-between items-center"
              >
                <div>
                  <h5 className="text-sm font-bold text-white">{s.name}</h5>
                  <p className="text-xs text-slate-400">ID: {s.id}</p>
                </div>
                <span className="px-2.5 py-1 bg-indigo-500/10 text-indigo-400 text-[10px] rounded-lg border border-indigo-500/20 font-semibold">
                  {s.class_id}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
