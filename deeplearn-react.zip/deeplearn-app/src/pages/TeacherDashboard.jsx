import React, { useEffect, useState } from 'react'
import { UploadCloud } from 'lucide-react'
import DashboardLayout from '../components/DashboardLayout'
import LessonCard from '../components/LessonCard'
import { useAuth } from '../context/AuthContext'
import { CLASS_OPTIONS, fetchLessonsByTeacher, insertLesson } from '../lib/api'

const EMPTY_FORM = { targetClass: 'F2', title: '', content: '', imageUrl: '', videoUrl: '' }

export default function TeacherDashboard() {
  const { currentUser } = useAuth()
  const [form, setForm] = useState(EMPTY_FORM)
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [myLessons, setMyLessons] = useState([])
  const [loadingLessons, setLoadingLessons] = useState(true)

  async function loadMyLessons() {
    setLoadingLessons(true)
    try {
      const lessons = await fetchLessonsByTeacher(currentUser.id)
      setMyLessons(lessons)
    } finally {
      setLoadingLessons(false)
    }
  }

  useEffect(() => {
    loadMyLessons()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function updateField(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      await insertLesson({
        target_class: form.targetClass,
        title: form.title,
        content: form.content,
        image_url: form.imageUrl || null,
        video_url: form.videoUrl || null,
        teacher_id: currentUser.id
      })
      setSuccess(true)
      setForm({ ...EMPTY_FORM, targetClass: form.targetClass })
      await loadMyLessons()
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <DashboardLayout
      title="Teacher Studio & Publishing"
      subtitle="Upload lessons with text, images, and videos to selected classes"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <div className="bg-cardBg p-6 rounded-3xl border border-slate-800/80 shadow-lg">
          <h4 className="font-bold text-base text-white mb-4 flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-indigo-400" /> Publish New Lesson
          </h4>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Select Target Class
              </label>
              <select
                value={form.targetClass}
                onChange={(e) => updateField('targetClass', e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
              >
                {CLASS_OPTIONS.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Lesson Title
              </label>
              <input
                type="text"
                required
                value={form.title}
                onChange={(e) => updateField('title', e.target.value)}
                placeholder="Tusaale: Newton's Laws of Motion"
                className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Lesson Text / Qoraalka Casharka
              </label>
              <textarea
                rows={5}
                required
                value={form.content}
                onChange={(e) => updateField('content', e.target.value)}
                placeholder="Ku qor faahfaahinta casharka halkan..."
                className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Image URL (Sawir)
                </label>
                <input
                  type="url"
                  value={form.imageUrl}
                  onChange={(e) => updateField('imageUrl', e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Video URL (Muuqaal)
                </label>
                <input
                  type="url"
                  value={form.videoUrl}
                  onChange={(e) => updateField('videoUrl', e.target.value)}
                  placeholder="https://youtube.com/..."
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-lg shadow-indigo-600/20 transition text-sm disabled:opacity-60"
            >
              {submitting ? 'Diraya...' : 'Publish Lesson to Class'}
            </button>
          </form>
          {success && (
            <div className="mt-4 p-3 bg-emerald-950/40 border border-emerald-900/40 text-emerald-400 text-xs rounded-xl text-center">
              ✅ Casharka si guul leh ayaa loo diray fasalka!
            </div>
          )}
          {error && (
            <div className="mt-4 p-3 bg-red-950/40 border border-red-900/40 text-red-400 text-xs rounded-xl text-center">
              Khalad ayaa dhacay: {error}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h4 className="font-bold text-sm text-white">Casharradaada la soo diray ({myLessons.length})</h4>
          <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1">
            {loadingLessons ? (
              <p className="text-xs text-slate-400">Soo dejinaya...</p>
            ) : myLessons.length === 0 ? (
              <p className="text-xs text-slate-400">Weli cashar ma dirin.</p>
            ) : (
              myLessons.map((l) => <LessonCard key={l.id} lesson={l} />)
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
