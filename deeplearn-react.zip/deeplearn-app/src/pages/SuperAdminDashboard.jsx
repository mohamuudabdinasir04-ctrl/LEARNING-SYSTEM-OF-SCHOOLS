import React, { useEffect, useMemo, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import StatCard from '../components/StatCard'
import { useSystemStatus } from '../context/SystemStatusContext'
import { fetchDirectory, fetchAllLessons, subscribeToLessons } from '../lib/api'

export default function SuperAdminDashboard() {
  const { active, toggleSystem } = useSystemStatus()
  const [directory, setDirectory] = useState([])
  const [lessons, setLessons] = useState([])
  const [loading, setLoading] = useState(true)
  const [toggling, setToggling] = useState(false)

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        const [dir, lsn] = await Promise.all([fetchDirectory(), fetchAllLessons()])
        if (mounted) {
          setDirectory(dir)
          setLessons(lsn)
        }
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
    const unsubscribe = subscribeToLessons((newLesson) => {
      setLessons((prev) => [newLesson, ...prev])
    })
    return () => {
      mounted = false
      unsubscribe()
    }
  }, [])

  const counts = useMemo(() => {
    const byRole = { super_admin: 0, school_admin: 0, teacher: 0, student: 0 }
    directory.forEach((p) => {
      if (byRole[p.role] !== undefined) byRole[p.role] += 1
    })
    return byRole
  }, [directory])

  const classBreakdown = useMemo(() => {
    const map = {}
    directory
      .filter((p) => p.role === 'student' && p.class_id)
      .forEach((p) => {
        map[p.class_id] = (map[p.class_id] || 0) + 1
      })
    return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0]))
  }, [directory])

  async function handleToggle() {
    setToggling(true)
    try {
      await toggleSystem()
    } catch (err) {
      alert('Khalad: ' + err.message)
    } finally {
      setToggling(false)
    }
  }

  return (
    <DashboardLayout
      title="Super Admin Control Center"
      subtitle="Global system analytics and remote switch control"
    >
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-cardBg p-5 rounded-2xl border border-slate-800/80 shadow-lg">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">System Power Status</p>
          <h4 className={`text-xl font-bold mt-1 ${active ? 'text-emerald-400' : 'text-red-400'}`}>
            {active ? 'ONLINE & RUNNING' : 'OFFLINE / RESTRICTED'}
          </h4>
          <button
            onClick={handleToggle}
            disabled={toggling}
            className={`mt-4 px-4 py-2 rounded-xl text-xs font-bold transition disabled:opacity-60 ${
              active ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {toggling ? 'Wax ka beddelaya...' : active ? 'Turn System OFF' : 'Turn System ON'}
          </button>
        </div>
        <StatCard
          label="Total Active Portals"
          value={`${Object.values(counts).filter((v) => v > 0).length || 4} Roles Connected`}
          hint="Admin, School, Teacher, Student"
        />
        <StatCard
          label="Cloud Database"
          value="Supabase Synced"
          hint="Realtime · Secure Profiles View"
          hintColor="text-emerald-400"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Super Admins" value={counts.super_admin} hintColor="text-indigo-400" />
        <StatCard label="School Admins" value={counts.school_admin} hintColor="text-sky-400" />
        <StatCard label="Teachers" value={counts.teacher} hintColor="text-emerald-400" />
        <StatCard label="Students" value={counts.student} hintColor="text-purple-400" />
      </div>

      <div className="bg-cardBg p-6 rounded-3xl border border-slate-800/80 shadow-lg">
        <h4 className="font-bold text-base text-white mb-4">Students per Class</h4>
        {loading ? (
          <p className="text-xs text-slate-400">Soo dejinaya...</p>
        ) : classBreakdown.length === 0 ? (
          <p className="text-xs text-slate-400">Wali ma jiraan ardayda loo diiwaan geliyay fasal.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {classBreakdown.map(([classId, count]) => (
              <div key={classId} className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
                <p className="text-lg font-bold text-white">{count}</p>
                <p className="text-[10px] text-slate-400 uppercase mt-1">{classId}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-cardBg p-6 rounded-3xl border border-slate-800/80 shadow-lg">
        <h4 className="font-bold text-base text-white mb-4">
          Live Feed — Lessons Across All Classes ({lessons.length})
        </h4>
        <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
          {lessons.length === 0 ? (
            <p className="text-xs text-slate-400">Wali lama soo gelin cashar.</p>
          ) : (
            lessons.slice(0, 25).map((l) => (
              <div
                key={l.id}
                className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 flex justify-between items-center"
              >
                <div>
                  <h5 className="text-sm font-bold text-white">{l.title}</h5>
                  <p className="text-xs text-slate-400">
                    Fasal: {l.target_class} · Macallin: {l.teacher_id} ·{' '}
                    {new Date(l.created_at).toLocaleString()}
                  </p>
                </div>
                <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-xs rounded-xl border border-emerald-500/20 font-semibold whitespace-nowrap">
                  Active
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
