import React from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import Login from './pages/Login'
import SuperAdminDashboard from './pages/SuperAdminDashboard'
import SchoolAdminDashboard from './pages/SchoolAdminDashboard'
import TeacherDashboard from './pages/TeacherDashboard'
import StudentDashboard from './pages/StudentDashboard'
import ProtectedRoute from './components/ProtectedRoute'
import { useAuth } from './context/AuthContext'

function RoleDashboard() {
  const { currentUser } = useAuth()
  switch (currentUser.role) {
    case 'super_admin':
      return <SuperAdminDashboard />
    case 'school_admin':
      return <SchoolAdminDashboard />
    case 'teacher':
      return <TeacherDashboard />
    case 'student':
      return <StudentDashboard />
    default:
      return <Navigate to="/login" replace />
  }
}

export default function App() {
  const { currentUser } = useAuth()

  return (
    <Routes>
      <Route path="/login" element={currentUser ? <Navigate to="/dashboard" replace /> : <Login />} />

      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <RoleDashboard />
          </ProtectedRoute>
        }
      />

      {/* Secondary sidebar links reuse the same role dashboard — mirrors
          the single-page nature of each portal (one screen per role). */}
      <Route
        path="/dashboard/overview"
        element={
          <ProtectedRoute allowRoles={['super_admin']}>
            <SuperAdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/school"
        element={
          <ProtectedRoute allowRoles={['school_admin']}>
            <SchoolAdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/publish"
        element={
          <ProtectedRoute allowRoles={['teacher']}>
            <TeacherDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/lessons"
        element={
          <ProtectedRoute allowRoles={['student']}>
            <StudentDashboard />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<Navigate to={currentUser ? '/dashboard' : '/login'} replace />} />
    </Routes>
  )
}
