import React, { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

const SystemStatusContext = createContext(null)

export function SystemStatusProvider({ children }) {
  const [active, setActive] = useState(true)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let channel

    async function load() {
      const { data, error } = await supabase
        .from('system_status')
        .select('active')
        .eq('id', 1)
        .single()
      if (!error && data) setActive(data.active)
      setLoading(false)
    }

    load()

    // Realtime: any user toggling the switch is reflected everywhere
    // else immediately, without a page refresh.
    channel = supabase
      .channel('system_status_changes')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'system_status' },
        (payload) => {
          if (payload.new) setActive(payload.new.active)
        }
      )
      .subscribe()

    return () => {
      if (channel) supabase.removeChannel(channel)
    }
  }, [])

  async function toggleSystem() {
    const newValue = !active
    const { error } = await supabase
      .from('system_status')
      .update({ active: newValue, updated_at: new Date().toISOString() })
      .eq('id', 1)
    if (error) throw error
    setActive(newValue) // optimistic; realtime event will confirm
  }

  return (
    <SystemStatusContext.Provider value={{ active, loading, toggleSystem }}>
      {children}
    </SystemStatusContext.Provider>
  )
}

export function useSystemStatus() {
  const ctx = useContext(SystemStatusContext)
  if (!ctx) throw new Error('useSystemStatus must be used within SystemStatusProvider')
  return ctx
}
