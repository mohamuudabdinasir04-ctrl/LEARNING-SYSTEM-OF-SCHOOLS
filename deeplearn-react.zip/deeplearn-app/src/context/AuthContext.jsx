import React, { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

const AuthContext = createContext(null)
const STORAGE_KEY = 'deeplearn_current_user'

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)
  const [initializing, setInitializing] = useState(true)

  useEffect(() => {
    try {
      const stored = sessionStorage.getItem(STORAGE_KEY)
      if (stored) setCurrentUser(JSON.parse(stored))
    } catch {
      sessionStorage.removeItem(STORAGE_KEY)
    }
    setInitializing(false)
  }, [])

  async function login(id, password) {
    // Password verification happens server-side inside the login_user
    // Postgres function (see supabase/migration.sql). The client never
    // sees or compares raw/hashed passwords.
    const { data, error } = await supabase.rpc('login_user', {
      p_id: id.trim(),
      p_password: password.trim()
    })

    if (error) {
      if (error.message?.includes('account_disabled')) {
        throw new Error('Akoonkaaga waxaa joojiyay maamulka.')
      }
      if (error.message?.includes('invalid_credentials')) {
        throw new Error('ID ama Password-ku waa qalad.')
      }
      throw new Error('Khalad ayaa dhacay. Fadlan isku day mar kale.')
    }

    const profile = Array.isArray(data) ? data[0] : data
    if (!profile) {
      throw new Error('ID-gan lama helin fadlan hubi.')
    }

    setCurrentUser(profile)
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(profile))
    return profile
  }

  function logout() {
    setCurrentUser(null)
    sessionStorage.removeItem(STORAGE_KEY)
  }

  return (
    <AuthContext.Provider value={{ currentUser, initializing, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
