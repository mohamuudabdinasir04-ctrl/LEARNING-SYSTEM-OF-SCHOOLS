import React, { useEffect, useRef, useState } from 'react'
import { Bot, Send } from 'lucide-react'
import { askCurriculumTutor } from '../lib/curriculumAI'

export default function ChatTutor({ lessons, studentClass }) {
  const [messages, setMessages] = useState([
    {
      role: 'ai',
      text: `Asc! Anigu ahay kaaliyahaaga AI ee ku xidhan manhajkaaga. Weydii wax kasta oo ku saabsan casharradaada ee fasalka ${studentClass}.`
    }
  ])
  const [input, setInput] = useState('')
  const boxRef = useRef(null)

  useEffect(() => {
    if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight
  }, [messages])

  function handleSubmit(e) {
    e.preventDefault()
    const query = input.trim()
    if (!query) return

    setMessages((prev) => [...prev, { role: 'student', text: query }])
    setInput('')

    setTimeout(() => {
      const result = askCurriculumTutor(query, lessons, studentClass)
      setMessages((prev) => [...prev, { role: 'ai', text: result.text }])
    }, 400)
  }

  return (
    <div className="bg-cardBg p-5 rounded-3xl border border-slate-800/80 shadow-lg flex flex-col h-[520px]">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-white">DeepLearn AI Tutor</h4>
            <p className="text-[10px] text-emerald-400">Strictly bound to class curriculum</p>
          </div>
        </div>
        <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded border border-emerald-500/20">
          Active 100%
        </span>
      </div>

      <div ref={boxRef} className="flex-grow overflow-y-auto py-4 space-y-3 pr-2 text-xs">
        {messages.map((m, i) =>
          m.role === 'student' ? (
            <div key={i} className="flex justify-end">
              <div className="bg-indigo-600 text-white p-3 rounded-2xl max-w-[85%]">{m.text}</div>
            </div>
          ) : (
            <div key={i} className="flex justify-start">
              <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800 max-w-[85%] text-slate-300">
                {m.text}
              </div>
            </div>
          )
        )}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2 pt-3 border-t border-slate-800">
        <input
          type="text"
          required
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Weydii su'aal ku saabsan casharka..."
          className="flex-grow px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
        />
        <button
          type="submit"
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition text-xs flex items-center justify-center"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  )
}
