import React from 'react'
import { LogOut } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Topbar({ title, subtitle }) {
  const { currentUser, logout } = useAuth()

  return (
    <header className="bg-cardBg/60 backdrop-blur border-b border-slate-800/80 px-6 py-3.5 flex justify-between items-center z-10">
      <div>
        <h3 className="font-bold text-sm text-white">{title}</h3>
        <p className="text-[11px] text-slate-400">{subtitle}</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <h4 className="text-xs font-bold text-white">{currentUser?.name}</h4>
          <p className="text-[10px] text-indigo-400 font-medium uppercase">{currentUser?.role}</p>
        </div>
        <button
          onClick={logout}
          title="Ka Bax"
          className="p-2 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-xl transition border border-red-500/20"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  )
}
