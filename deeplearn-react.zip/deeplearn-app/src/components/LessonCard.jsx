import React from 'react'

export default function LessonCard({ lesson }) {
  return (
    <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 space-y-3">
      <div className="flex justify-between items-start gap-3">
        <h5 className="font-bold text-white text-sm">{lesson.title}</h5>
        <span className="text-[10px] px-2.5 py-1 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20 whitespace-nowrap">
          {lesson.target_class}
        </span>
      </div>
      <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">{lesson.content}</p>
      {lesson.image_url && (
        <img
          src={lesson.image_url}
          alt={lesson.title}
          className="rounded-xl max-h-48 object-cover w-full mt-2"
          onError={(e) => {
            e.currentTarget.style.display = 'none'
          }}
        />
      )}
      {lesson.video_url && (
        <a
          href={lesson.video_url}
          target="_blank"
          rel="noreferrer"
          className="text-[11px] text-indigo-400 hover:text-indigo-300 underline block"
        >
          🎬 Daawo muuqaalka casharka
        </a>
      )}
      <span className="text-[10px] text-slate-500 block">
        Posted on: {new Date(lesson.created_at).toLocaleDateString()}
      </span>
    </div>
  )
}
