import React from 'react'
import { NavLink } from 'react-router-dom'
import { GraduationCap, LayoutDashboard, Eye, Users, UploadCloud, BookOpen } from 'lucide-react'

const ROLE_LINKS = {
  super_admin: [{ to: '/dashboard/overview', label: 'System Global View', icon: Eye }],
  school_admin: [{ to: '/dashboard/school', label: 'Teachers & Students', icon: Users }],
  teacher: [{ to: '/dashboard/publish', label: 'Post Lesson', icon: UploadCloud }],
  student: [{ to: '/dashboard/lessons', label: 'My Lessons & AI', icon: BookOpen }]
}

export default function Sidebar({ role }) {
  const extraLinks = ROLE_LINKS[role] || []

  const linkClass = ({ isActive }) =>
    `flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition ${
      isActive
        ? 'bg-indigo-600/10 text-indigo-400 font-semibold border border-indigo-500/20'
        : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
    }`

  return (
    <aside className="w-64 bg-sidebarBg border-r border-slate-800/80 flex flex-col z-20">
      <div className="p-5 border-b border-slate-800/60 flex items-center gap-3">
        <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white shadow-md">
          <GraduationCap className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-bold text-sm text-white">DeepLearn Portal</h2>
          <p className="text-[10px] text-indigo-400 font-medium uppercase">{role?.replace('_', ' ')}</p>
        </div>
      </div>
      <nav className="flex-grow p-4 space-y-1.5 overflow-y-auto">
        <NavLink to="/dashboard" end className={linkClass}>
          <LayoutDashboard className="w-4 h-4" /> Dashboard
        </NavLink>
        {extraLinks.map((link) => (
          <NavLink key={link.to} to={link.to} className={linkClass}>
            <link.icon className="w-4 h-4" /> {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
