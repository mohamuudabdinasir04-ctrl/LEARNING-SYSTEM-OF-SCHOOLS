import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function ProtectedRoute({ children, allowRoles }) {
  const { currentUser, initializing } = useAuth()

  if (initializing) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate-400 text-sm">
        Soo dejinaya...
      </div>
    )
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />
  }

  if (allowRoles && !allowRoles.includes(currentUser.role)) {
    return <Navigate to="/dashboard" replace />
  }

  return children
}
