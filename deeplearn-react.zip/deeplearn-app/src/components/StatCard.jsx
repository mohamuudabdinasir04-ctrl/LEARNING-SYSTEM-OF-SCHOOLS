import React from 'react'

export default function StatCard({ label, value, hint, hintColor = 'text-indigo-400' }) {
  return (
    <div className="bg-cardBg p-5 rounded-2xl border border-slate-800/80 shadow-lg">
      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{label}</p>
      <h4 className="text-2xl font-bold text-white mt-1">{value}</h4>
      {hint && <span className={`text-[10px] ${hintColor} mt-2 block`}>{hint}</span>}
    </div>
  )
}
