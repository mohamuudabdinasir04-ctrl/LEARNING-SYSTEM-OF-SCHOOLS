import React from 'react'
import { ShieldAlert } from 'lucide-react'

export default function OfflineNotice() {
  return (
    <div className="flex-grow flex items-center justify-center p-6">
      <div className="p-12 text-center bg-cardBg rounded-3xl border border-red-500/30 max-w-lg">
        <div className="w-16 h-16 bg-red-500/10 text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Nidaamka Waa la Xadiday</h2>
        <p className="text-xs text-slate-400 mb-6">
          Maamulka guud (Super Admin) ayaa ku meel gaar ah u xiray nidaamka sababo la xiriira dayactir ama ammaan
          awgeed. Fadlan dib ugu soo noqo markale.
        </p>
      </div>
    </div>
  )
}
