import React from 'react'
import { useAuth } from '../context/AuthContext'
import { useSystemStatus } from '../context/SystemStatusContext'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import OfflineNotice from './OfflineNotice'

export default function DashboardLayout({ title, subtitle, children }) {
  const { currentUser } = useAuth()
  const { active } = useSystemStatus()

  const isOffline = !active && currentUser?.role !== 'super_admin'

  return (
    <div className="flex flex-col h-screen">
      {isOffline && (
        <div className="bg-red-600 text-white text-center py-2 text-xs font-bold uppercase tracking-wider z-50">
          ⚠️ Digniin: Nidaamka waxaa xiray / xadiday Maamulka Guud (Super Admin). Adeegyada waa la hakiyay.
        </div>
      )}
      <div className="flex-grow flex overflow-hidden">
        <Sidebar role={currentUser?.role} />
        <div className="flex-grow flex flex-col bg-darkBg overflow-hidden">
          <Topbar title={title} subtitle={subtitle} />
          <main className="flex-grow overflow-y-auto p-6 space-y-6">
            {isOffline ? <OfflineNotice /> : children}
          </main>
        </div>
      </div>
    </div>
  )
}
