/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Inter', 'sans-serif'] },
      colors: {
        darkBg: '#090d16',
        cardBg: '#111827',
        sidebarBg: '#0d1322',
        accent: '#4f46e5'
      }
    }
  },
  plugins: []
}
