# DeepLearn — Multi-Portal School System (React + Supabase)

4 dashboards oo kala duwan, mid kasta gaar u ah role-kiisa:

| Role | Route | Waxa uu arki karo |
|---|---|---|
| `super_admin` | `/dashboard` | Analytics guud, on/off switch nidaamka oo dhan, arag toos ah oo dhammaan school admin/teacher/student |
| `school_admin` | `/dashboard` | Liiska macallimiinta iyo ardayda, kala saarid fasalka |
| `teacher` | `/dashboard` | Foomka soo gelinta cashar (qoraal, sawir URL, video URL) + fasalka loo diro |
| `student` | `/dashboard` | Casharrada fasalkiisa + AI Tutor 100% ku xiran manhajka |

## 1. Isku dubbaridka Supabase

1. Fur Supabase Dashboard → **SQL Editor**.
2. Ku shub oo run garee faylka `supabase/migration.sql`. Waxay:
   - Hash-gareysaa password-yada jira ee `profiles`.
   - Xirtaa read/write-ka tooska ah ee `profiles` (RLS).
   - Abuurtaa RPC `login_user(id, password)` — login-ku halkan ayuu ka dhacaa, server-side.
   - Abuurtaa view `profiles_directory` (id, name, role, class_id, status — **mana lahan password**) oo Super/School Admin ay ku arkaan macallimiinta iyo ardayda.
   - Abuurtaa jadwallada `lessons` iyo `system_status`, kuwaas oo dhammaan users-ku isla wadaagaan.
   - Ku daraa `lessons` iyo `system_status` publication-ka realtime-ka si isbeddel kastaa (cashar cusub, on/off) isla markiiba loogu muujiyo dhammaan users-ka fadhiya app-ka — la'aanteed refresh.

3. Hubi in jadwalka `profiles` ay leeyihiin columns-kan: `id text primary key`, `name text`, `role text` (`super_admin` | `school_admin` | `teacher` | `student`), `class_id text` (ardayda/macallimiinta), `password text`, `status text` (`ACTIVE` / kale).

⚠️ **Xasuus muhiim ah**: app-kani wuxuu isticmaalaa login custom (mana isticmaalo Supabase Auth), sidaa darteed `profiles_directory`, `lessons`, iyo `system_status` waa la wadaago dhammaan qofka haysta anon key-ga — sida app-kii hore. Haddii aad rabto in role-yadu si xaqiiqo ah RLS-ka ugu xakameeyaan (tusaale: kaliya super_admin uu beddeli karo `system_status`), waxaad u baahan tahay in login-ka lagu beddelo Supabase Auth.

## 2. Isku dubbaridka app-ka

```bash
npm install
cp .env.example .env
# .env ku dhig VITE_SUPABASE_URL iyo VITE_SUPABASE_ANON_KEY (waa la buuxiyay durba tusaale ahaan)
npm run dev
```

App-ku wuxuu ku furmayaa `http://localhost:5173`.

## 3. AI Tutor-ka ardayda

AI-gu **ma isticmaalo API bixiye dibadeed** (OpenAI/Anthropic iwm) — wuxuu isticmaalaa is-barbardhig ereyo (`src/lib/curriculumAI.js`) oo su'aasha ardayga ku barbardhiga casharrada fasalkiisa oo keliya, kadibna ka soo qaata jawaabta sadar/sentences-ka ugu dhow su'aasha. Haddii aan wax cashar ah la helin oo ku filan (score hoosaysa), wuxuu si cad u diidaa inuu ka jawaabo — sidaas ma "invent-gareyn" doono wax ka baxsan manhajka.

Haddi mustaqbalka aad rabto AI dhab ah (LLM), waxaad u baahan tahay:
1. Supabase Edge Function oo ku xidhan OpenAI/Anthropic API key (loo kaydiyo Supabase secrets, **weligiis lama geliyo frontend-ka**).
2. `ChatTutor.jsx` ku beddel `supabase.functions.invoke('ai-tutor', { body: { query, lessons } })` halkii `askCurriculumTutor` ee local ahayd.

## 4. Deploy

`npm run build` wuxuu soo saaraa `dist/` — waxaad geyn kartaa Vercel, Netlify, Cloudflare Pages, ama server kasta oo static files u adeegi kara. Xasuus inaad environment variables-ka (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) ku dartid platform-ka deploy-ka.
